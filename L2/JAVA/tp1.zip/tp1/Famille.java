public enum Famille{

Pique,Coeur,Trefle,Carreau;
}
