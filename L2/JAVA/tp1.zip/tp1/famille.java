public enum famille{Pique,Coeur,Trefle,Carreau;}
