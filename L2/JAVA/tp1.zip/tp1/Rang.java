public enum Rang{

As,Deux,Trois,Roi;
}
