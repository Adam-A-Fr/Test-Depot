public enum rang{As,Deux,Trois,Roi;}
